<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
     
    protected $table = 'products';
    protected $primaryKey = 'id';
    public $timestamps = false;
    
}
class Slide extends Model
{
    protected $table = 'slide';
    protected $primaryKey = 'id';
    public $timestamps = false;
}