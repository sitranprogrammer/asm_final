<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\product;
use DB;
use App\Quotation;
class PageCotroller extends Controller
{
    
    public function index(){
        $product = Product::all()->take(8);
        $slide =  Product::all()->take(5);
        return view('page.trangchu',
         [
            'product'=>$product,
            'slide'=>$slide,
           
        ]);
    }
   public function getproduct(request $req)
   {
    $product_one = Product::where('id',$req->id)->first();
     return view('page.product',['get_product'=>$product_one]);
   }
   public function  GetCart()
   {
   
     return view('page.cart');
   }
   public function GetProductByCatalog(request $req)
   {
 
    $product_one = Product::all()->where('id_type',$req->id);
    return view('page.select_product',['get_product'=>$product_one]);

   }
}
