<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Slider;
use DB;
use App\Quotation;
class PageCotroller extends Controller
{
    
    public function index(){
        $slide = Slide::all()->take(2);

        return view('page.trangchu',
         [
            'slide'=>$slide,
           
        ]);
    }
}
 