<?php


Route::get('/', [
        'as'=>'trang-chu',

        'uses'=>'PageCotroller@index',

    ]
 
);

Route::get('/product={id}',[
    'as'=>'product',

    'uses'=>'PageCotroller@getproduct',
    
]

);

Route::get('/selectproduct={id}',[
    'as'=>'selectproduct',

    'uses'=>'PageCotroller@GetProductByCatalog',
    
]

);



Route::group(['prefix' => 'admin'], function () {
    Voyager::routes();
});
